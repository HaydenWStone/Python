import turtle

class Scoreboard(turtle.Turtle):
    #Initialize scoreboard
    def __init__(self,score):
        super().__init__()
        self.penup()
        self.hideturtle()
        self.goto(0, 280)
        self.color("white")
        self.write(f"Score: {score}",move=False,align='center',font=('Arial',14,'bold'))

    #Increase score
    def refresh(self,score):
        self.clear()
        self.write(f"Score: {score}", move=False, align='center', font=('Arial', 14, 'bold'))

    #Write GAME OVER message
    def gameover(self):
        self.goto(0, 0)
        self.write("GAME OVER", move=False, align='center', font=('Arial', 14, 'bold'))